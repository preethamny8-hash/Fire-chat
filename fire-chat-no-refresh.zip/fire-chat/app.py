import os
import re
import uuid
import sqlite3
import logging
import time
from collections import defaultdict, deque
from datetime import datetime, timezone
from pathlib import Path

from dotenv import load_dotenv
from flask import Flask, jsonify, render_template, request, g
from werkzeug.utils import secure_filename
from werkzeug.exceptions import RequestEntityTooLarge
from PIL import Image, UnidentifiedImageError
from google import genai
from google.genai import types

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 8 * 1024 * 1024  # request incl. image <= 8 MB
app.config["JSON_SORT_KEYS"] = False
DB_PATH = Path(os.getenv("DATABASE_PATH", BASE_DIR / "database" / "fire_chat.sqlite3"))
DB_PATH.parent.mkdir(parents=True, exist_ok=True)
MODEL_NAME = os.getenv("GEMINI_MODEL", "gemini-3.8-flash")
MAX_MESSAGE_CHARS = 12000
MAX_HISTORY_MESSAGES = 40
RATE_WINDOW_SECONDS = 60
RATE_MAX_REQUESTS = 20
_rate_events = defaultdict(deque)
ALLOWED_MIME = {"image/png", "image/jpeg", "image/webp"}
logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"))
log = logging.getLogger("fire-chat")


def db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH, timeout=15)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(_error=None):
    conn = g.pop("db", None)
    if conn is not None:
        conn.close()


def init_db():
    conn = sqlite3.connect(DB_PATH)
    conn.executescript("""
        PRAGMA journal_mode=WAL;
        CREATE TABLE IF NOT EXISTS chats (
            id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            chat_id TEXT NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
            role TEXT NOT NULL CHECK(role IN ('user','assistant')),
            content TEXT NOT NULL,
            image_name TEXT,
            created_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_messages_chat ON messages(chat_id, id);
    """)
    conn.commit()
    conn.close()


def now_iso():
    return datetime.now(timezone.utc).isoformat()


def get_chat(chat_id):
    return db().execute("SELECT * FROM chats WHERE id=?", (chat_id,)).fetchone()


def serialize_message(row):
    return {"id": row["id"], "role": row["role"], "content": row["content"],
            "image_name": row["image_name"], "created_at": row["created_at"]}


def gemini_client():
    key = os.getenv("GEMINI_API_KEY", "").strip()
    if not key:
        raise RuntimeError("The server is missing GEMINI_API_KEY. Add it to your .env file.")
    return genai.Client(api_key=key)


@app.get("/")
def index():
    return render_template("index.html")


@app.get("/api/chats")
def list_chats():
    rows = db().execute(
        "SELECT c.id,c.title,c.created_at,c.updated_at,COUNT(m.id) AS message_count "
        "FROM chats c LEFT JOIN messages m ON m.chat_id=c.id "
        "GROUP BY c.id ORDER BY c.updated_at DESC"
    ).fetchall()
    return jsonify([dict(r) for r in rows])


@app.post("/api/chats")
def create_chat():
    chat_id = str(uuid.uuid4())
    timestamp = now_iso()
    db().execute("INSERT INTO chats(id,title,created_at,updated_at) VALUES(?,?,?,?)",
                 (chat_id, "New conversation", timestamp, timestamp))
    db().commit()
    return jsonify({"id": chat_id, "title": "New conversation"}), 201


@app.get("/api/chats/<chat_id>")
def read_chat(chat_id):
    chat = get_chat(chat_id)
    if not chat:
        return jsonify({"error": "Conversation not found."}), 404
    rows = db().execute("SELECT * FROM messages WHERE chat_id=? ORDER BY id", (chat_id,)).fetchall()
    return jsonify({"chat": dict(chat), "messages": [serialize_message(r) for r in rows]})


@app.delete("/api/chats/<chat_id>")
def delete_chat(chat_id):
    cur = db().execute("DELETE FROM chats WHERE id=?", (chat_id,))
    db().commit()
    if cur.rowcount == 0:
        return jsonify({"error": "Conversation not found."}), 404
    return jsonify({"ok": True})


@app.delete("/api/chats/<chat_id>/messages")
def clear_chat(chat_id):
    if not get_chat(chat_id):
        return jsonify({"error": "Conversation not found."}), 404
    db().execute("DELETE FROM messages WHERE chat_id=?", (chat_id,))
    db().execute("UPDATE chats SET title='New conversation', updated_at=? WHERE id=?", (now_iso(), chat_id))
    db().commit()
    return jsonify({"ok": True})


def make_history(chat_id):
    rows = db().execute(
        "SELECT role,content FROM messages WHERE chat_id=? ORDER BY id DESC LIMIT ? OFFSET 1",
        (chat_id, MAX_HISTORY_MESSAGES)
    ).fetchall()
    rows = list(reversed(rows))
    return [types.Content(role="user" if r["role"] == "user" else "model",
                          parts=[types.Part.from_text(text=r["content"])]) for r in rows]


@app.post("/api/chats/<chat_id>/messages")
def send_message(chat_id):
    chat = get_chat(chat_id)
    if not chat:
        return jsonify({"error": "Conversation not found."}), 404

    text = (request.form.get("message") or "").strip()
    upload = request.files.get("image")
    if not text and not upload:
        return jsonify({"error": "Write a message or attach an image."}), 400
    if len(text) > MAX_MESSAGE_CHARS:
        return jsonify({"error": f"Messages must be {MAX_MESSAGE_CHARS:,} characters or fewer."}), 413

    image_bytes, mime, image_name = None, None, None
    if upload and upload.filename:
        image_name = secure_filename(upload.filename)[:120] or "image"
        image_bytes = upload.read()
        if not image_bytes or len(image_bytes) > 7 * 1024 * 1024:
            return jsonify({"error": "Images must be smaller than 7 MB."}), 400
        try:
            image = Image.open(__import__("io").BytesIO(image_bytes))
            image.verify()
            mime = Image.MIME.get(image.format)
        except (UnidentifiedImageError, OSError, ValueError):
            return jsonify({"error": "That file is not a valid image."}), 400
        if mime not in ALLOWED_MIME:
            return jsonify({"error": "Use a PNG, JPEG, or WebP image."}), 400

    prompt_text = text or "Please describe and explain this image."
    timestamp = now_iso()
    conn = db()
    conn.execute("INSERT INTO messages(chat_id,role,content,image_name,created_at) VALUES(?,?,?,?,?)",
                 (chat_id, "user", prompt_text, image_name, timestamp))
    existing_count = conn.execute("SELECT COUNT(*) FROM messages WHERE chat_id=?", (chat_id,)).fetchone()[0]
    if existing_count == 1:
        title = re.sub(r"\s+", " ", prompt_text).strip()[:48] or "Image conversation"
        conn.execute("UPDATE chats SET title=?,updated_at=? WHERE id=?", (title, timestamp, chat_id))
    else:
        conn.execute("UPDATE chats SET updated_at=? WHERE id=?", (timestamp, chat_id))
    conn.commit()

    try:
        client = gemini_client()
        history = make_history(chat_id)
        parts = [types.Part.from_text(text=prompt_text)]
        if image_bytes:
            parts.append(types.Part.from_bytes(data=image_bytes, mime_type=mime))
        history.append(types.Content(role="user", parts=parts))
        response = client.models.generate_content(
            model=MODEL_NAME,
            contents=history,
            config=types.GenerateContentConfig(
                system_instruction=(
                    "You are Fire Chat, a helpful, accurate AI assistant. "
                    "Answer clearly, support coding and learning, and format responses with Markdown. "
                    "Do not claim to be a separately trained Fire Chat model."
                ),
                temperature=0.7,
            ),
        )
        answer = (response.text or "").strip()
        if not answer:
            answer = "I couldn't produce a text response. Please try again."
    except Exception as exc:
        log.exception("Gemini request failed")
        # Avoid returning provider internals or credentials to the browser.
        message = "The AI service is temporarily unavailable. Please try again."
        if isinstance(exc, RuntimeError) and "GEMINI_API_KEY" in str(exc):
            message = "Fire Chat is not configured yet. Add GEMINI_API_KEY to the server environment."
        return jsonify({"error": message}), 503

    timestamp = now_iso()
    conn.execute("INSERT INTO messages(chat_id,role,content,created_at) VALUES(?,?,?,?)",
                 (chat_id, "assistant", answer, timestamp))
    conn.execute("UPDATE chats SET updated_at=? WHERE id=?", (timestamp, chat_id))
    conn.commit()
    row = conn.execute("SELECT * FROM messages WHERE id=last_insert_rowid()").fetchone()
    return jsonify({"message": serialize_message(row)})


@app.errorhandler(RequestEntityTooLarge)
def too_large(_error):
    return jsonify({"error": "The request is too large. Images must be under 7 MB."}), 413


@app.errorhandler(429)
def too_many(_error):
    return jsonify({"error": "Too many requests. Please wait a moment and try again."}), 429


init_db()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "5000")), debug=os.getenv("FLASK_DEBUG") == "1")
