# Fire Chat

A responsive dark-theme AI chat web app built with Flask, SQLite, HTML, CSS and JavaScript. The server calls the official Google Gen AI Python SDK; the browser never receives the API key. Fire Chat does not use Google Search grounding.

## Requirements

- Python 3.10+
- A Gemini API key from [Google AI Studio](https://aistudio.google.com/app/apikey)
- Internet access from the server to the Gemini API

## Run locally

```bash
cd fire-chat
python -m venv .venv
# Windows: .venv\Scripts\activate
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

Edit `.env` and set `GEMINI_API_KEY` to your key. Do not put the key in frontend files or commit `.env`.

```bash
python app.py
```

Open http://127.0.0.1:5000.

## Features

- Gemini-powered text and image conversations (PNG, JPEG, WebP; under 7 MB)
- SQLite chat sessions and message persistence
- Conversation context (most recent 40 messages)
- Markdown rendering, syntax-highlighted code blocks, copy and regenerate actions
- Stop-generation button (cancels the browser request; provider-side work may continue)
- Responsive mobile sidebar, chat deletion and clear-chat controls
- Server-side key storage, upload validation, request-size cap and basic in-process per-IP rate limiting (20 API requests per minute)

## Configuration

| Variable | Default | Purpose |
|---|---|---|
| `GEMINI_API_KEY` | — | Required secret |
| `GEMINI_MODEL` | `gemini-3.8-flash` | Model identifier |
| `DATABASE_PATH` | `database/fire_chat.sqlite3` | SQLite file location |
| `PORT` | `5000` | Local server port |
| `FLASK_DEBUG` | `0` | Set to `1` only for local debugging |

For a production deployment, use a persistent disk/volume and set `DATABASE_PATH` to a location on it. SQLite data on an ephemeral filesystem can be lost on redeploy. Use HTTPS.

## Deploy (generic Python host)

1. Push this folder to a private or public GitHub repository. Ensure `.env` is not committed.
2. Create a Python web service from the repository.
3. Build/install command: `pip install -r requirements.txt`.
4. Start command: `gunicorn app:app --workers 2 --threads 4 --timeout 120` (also provided in `Procfile`).
5. Add `GEMINI_API_KEY` and optionally `GEMINI_MODEL` in the host's environment-variable/secret settings.
6. Attach a persistent disk and set `DATABASE_PATH` to a writable file on it.
7. Deploy and open the HTTPS URL.

## Upload to GitHub

```bash
git init
git add .
git status                 # confirm .env is NOT listed
git commit -m "Build Fire Chat"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/fire-chat.git
git push -u origin main
```

If a real key was ever committed, revoke it and create a new one immediately.

## Security and production notes

- API credentials are read only by Python from environment variables.
- Request body is capped at 8 MB; individual images are capped at 7 MB and verified as PNG/JPEG/WebP.
- Provider errors are logged server-side and generic messages are returned to clients.
- This starter is intended for a single-user/private deployment. It does not implement user accounts, per-user data isolation, CSRF protection, or a distributed rate limiter. Put it behind an authenticated access layer before exposing private conversations publicly. Add Redis-backed rate limiting, CSRF protection and user authentication for a public multi-user service. The built-in in-memory limiter is per process and is not suitable as a distributed abuse-control system.
- The Stop button cancels the browser fetch and prevents its result from being displayed; the synchronous Gemini request may continue on the server until the provider returns.
